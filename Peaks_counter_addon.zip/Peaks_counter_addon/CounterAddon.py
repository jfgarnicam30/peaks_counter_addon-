#    NeuroMorph_import_obj_batch.py (C) 2014,  Diego Marcos, Corrado Cali, Biagio Nigro, Anne Jorstad
#
#    This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation, either version 3 of the License, or
#    (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with this program.  If not, see http://www.gnu.org/licenses/

bl_info={"name": "Peaks counter",
    "version": (1, 2, 3),
    "blender": (2, 7, 9),
    "location": "Scene > Wavefront (.obj) Batch Import",
    "description": "Import, count and export a list with the quantity of peaks in the current directory",
    "warning": "",  
    "wiki_url": "",  
    "tracker_url": "",  
    "category": "Import-Export"}  

import bmesh
import bpy
import math
import numpy as np
import csv
from os import listdir 


#Global variables:
counter_color = np.zeros((5,),dtype=np.int) # five dimensions for five sectors
colors = np.array(["Blue", "Turquoise", "Green", "Yellow", "Red",]) #Five colors
peaks_dict = { }



def load_uv_image():
    bpy.ops.image.open(filepath=bpy.utils.user_resource('SCRIPTS', "addons")+"/Peaks_counter_addon/"+"peak.jpg", directory=bpy.utils.user_resource('SCRIPTS', "addons")+"/Peaks_counter_addon/", files=[{"name":"peak.jpg", "name":"peak.jpg"}], relative_path=True)
    
def map_colors(obj_name):
    ob = bpy.data.objects[obj_name]
    print(ob.name)
    img_w = bpy.data.images['peak.jpg'].size[0]#1241
    img_h = bpy.data.images['peak.jpg'].size[1]#92
    length_sector = round((img_w/5)-1) #divide according number of sector you need
    
    counter_color = np.zeros((5,),dtype=np.int)
    peaks_dict[obj_name] = counter_color

    ob_verts = ob.data.vertices
    ob_faces = ob.data.polygons

    print("generals:")
    print(len(ob_verts))
    print( len(ob_faces))

    rgb=[]
    count=0
    for p in ob.data.polygons:
        #get uv coords
        uv_co = ob.data.uv_layers.active.data[count].uv #values between 0 and 1
        #get pixel coords in image
        x_pix = round(uv_co[0]*(img_w-1))
        y_pix = round(uv_co[1]*(img_h-1))        
        #get pixel color
        pixel_indx = (img_w * y_pix) + x_pix
        r = bpy.data.images['peak.jpg'].pixels[pixel_indx*4]
        g = bpy.data.images['peak.jpg'].pixels[pixel_indx*4 + 1]
        b = bpy.data.images['peak.jpg'].pixels[pixel_indx*4 + 2]
        val=[int(r*255),int(g*255),int(b*255)]
        
        if(val not in rgb):
            #peaks_dict[obj_name] = peaks_dict.get(obj_name)+1
            rgb.append([int(r*255),int(g*255),int(b*255)])
            #print(x_pix)
            if( x_pix >= 0 and x_pix <= length_sector):
                counter_color[0]+=1
            elif (x_pix > length_sector   and x_pix <= length_sector*2):
                counter_color[1]+=1
            elif (x_pix > length_sector*2 and x_pix <= length_sector*3):
                counter_color[2]+=1
            elif (x_pix > length_sector*3 and x_pix <= length_sector*4):
                counter_color[3]+=1
            elif (x_pix > length_sector*4 and x_pix <= length_sector*5):
                counter_color[4]+=1
        peaks_dict[obj_name]=counter_color
        count+=450  
        if (count >= len(ob_faces)*3):     
            break    


# create a csv file with information of color and quantity of peaks
def createCSVFile(directory):
    with open(directory+'/PeaksList.csv', 'w') as csvfile:
        filewriter = csv.writer(csvfile, delimiter=',',quotechar='"', quoting=csv.QUOTE_MINIMAL)
        
        blender_file = bpy.path.basename(bpy.context.blend_data.filepath)
        filewriter.writerow( ['Blender file: ' + blender_file] )
        filewriter.writerow( '' )
            
        filewriter.writerow( '' )
        filewriter.writerow( ['Cell', "Blue", "Turquoise", "Green", "Yellow", "Red" ] )#heading
        for key,val in peaks_dict.items():
            filewriter.writerow( [key, peaks_dict.get(key)[0], peaks_dict.get(key)[1], peaks_dict.get(key)[2], peaks_dict.get(key)[3], peaks_dict.get(key)[4], ] )


# main function
def counter(directory):
    load_uv_image()
    objects = bpy.context.scene.objects
    
    possible_name = "peaks"
    possible_name1 = "peak"
    possible_name2 = "PEAKS"
    possible_name3 = "PEAK"
    
    for obj in objects:
        if ((possible_name or possible_name1 or possible_name2 or possible_name3) in obj.name):
            map_colors(obj.name)     
            print ('\n')
    createCSVFile(directory)
    print(peaks_dict)



from bpy.props import StringProperty, FloatVectorProperty

class CountOperator(bpy.types.Operator):
    """Tooltip"""
    bl_idname = "object.count_operator"
    bl_label = "Count"
    
    directory="nothing"

    def execute(self, context):
        CountWavefrontPanel.file_message = "This may take few minutes"
        counter(self.directory)
        CountWavefrontPanel.file_message = "Doc created!"
        print("finish")
        return {'FINISHED'}

# Define the import panel within the Scene panel
class CountWavefrontPanel(bpy.types.Panel):
    bl_label = "Count peaks"
    bl_space_type = "PROPERTIES"
    bl_region_type = "WINDOW"
    bl_context = "scene"
    
    print(55)
    
    file_message=""
    
    def draw(self, context):
        row = self.layout.row()
        row.operator("import.obj", text='Import Object(s)', icon='MESH_ICOSPHERE')
        row = self.layout.row()
        row.operator("object.count_operator")
        layout = self.layout 
        layout.label(self.file_message)
             

class ObjImportButton(bpy.types.Operator):
    """Objects will be resized by the scale provided"""
    bl_idname = "import.obj"
    bl_label = "Import (might take several minutes)"
 
    directory = bpy.props.StringProperty(subtype="FILE_PATH")
    files = bpy.props.CollectionProperty(name='File path', type=bpy.types.OperatorFileListElement)
    
    def execute(self, context):
        #print(self.directory)
        #files = os.listdir(self.directory)
        #ObjBatchImport(self.directory,files)

        items = [file.name for file in self.files]
        ObjBatchImport(self.directory,items)
        CountOperator.directory = self.directory
        return {'FINISHED'} 
    
    def invoke(self, context, event):
        context.window_manager.fileselect_add(self)
        return {'RUNNING_MODAL'}         


def ObjBatchImport(dir,files):
    if bpy.ops.object.mode_set.poll():
        bpy.ops.object.mode_set(mode='OBJECT')

    old_objects = bpy.data.objects[:]

    possible_name = "peaks"
    possible_name1 = "peak"
    possible_name2 = "PEAKS"
    possible_name3 = "PEAK"

    for f in files:
        if ((f[-4:] == '.obj') and (possible_name or possible_name1 or possible_name2 or possible_name3) in f):
            bpy.ops.import_scene.obj(filepath=dir + f)

              
def register():
    bpy.utils.register_class(CountOperator) 
    bpy.utils.register_class(CountWavefrontPanel) 
    bpy.utils.register_class(ObjImportButton)
    

def unregister():
    bpy.utils.unregister_class(CountOperator)
    bpy.utils.unregister_class(CountWavefrontPanel)


if __name__ == "__main__":
    register()  






